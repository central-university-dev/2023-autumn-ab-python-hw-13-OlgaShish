from typing import Any, Optional
import PyJWT
import json
from datetime import datetime, timedelta


def read_token(body: dict) -> Optional[Any]:
    config = open("config.json")
    key_word = json.load(config)
    token = body.get("token", None)
    if token is None:
        return None
    jwt_token = PyJWT.decode(token, key_word, algorithms=["HS256"])
    return jwt_token["user_id"]


def make_token(user_id: Any) -> str:
    config = open("config.json")
    key_word = json.load(config)["key_word"]
    json_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(user_id)
    body = {"user_id": str(user_id), "time": str(json_time)}
    print(body)
    token = PyJWT.encode(body, key_word, algorithm="HS256")
    return token


def is_token_need_refresh(body: dict) -> bool:
    jwt_token = read_token(body)
    if jwt_token is None:
        return True
    time = datetime.strptime(jwt_token["time"], "%m/%d/%y %H:%M:%S")
    if datetime.now() - time > timedelta(hours=1):
        return True
    else:
        return False
