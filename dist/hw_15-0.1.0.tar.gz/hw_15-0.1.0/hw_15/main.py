from typing import Any, Optional
from hw_15.token import read_token, make_token, is_token_need_refresh
import json

import hw_15.app as app


class RequestTypeError(Exception):
    pass


class EndpointError(Exception):
    pass


async def read_body(receive: Any) -> Optional[Any]:
    """
    Read and return the entire body from an incoming ASGI message.
    """
    body = b''
    more_body = True

    while more_body:
        message = await receive()
        print(message)
        print(message.get('body', b''))
        body += message.get('body', b'')
        more_body = message.get('more_body', False)
    if body != b'':
        res_body = json.loads(body)
        return res_body
    else:
        return None


async def send_response(send: Any,
                        body: Optional[dict],
                        new_token: Optional[str],
                        need_update: bool):
    if need_update:
        await send({
            'type': 'http.response.start',
            'status': 403,
            'headers': [
                [b'content-type', b'text/plain'],
            ],
        })

        await send({
            'type': 'http.response.body',
            'response': "pls, relogin",
        })

    if body is not None or new_token is not None:
        await send({
            'type': 'http.response.start',
            'status': 200,
            'headers': [
                [b"access-control-allow-origin", b'*'],
                [b'content-type', b'application/json']
            ],
        })

        response: dict[str, Any] = {}
        if new_token is not None:
            response['token'] = new_token

        if body is not None:
            response['body'] = body
        await send({
            'type': 'http.response.body',
            'response': response,
        })


async def application(scope, receive, send):
    assert scope['type'] == 'http'
    body = await read_body(receive)
    if body is not None:
        body = body['body']
        user_id = read_token(body)
        need_update = is_token_need_refresh(body)
        res = None
        new_token = None
        try:
            match (scope['path'], scope['method']):  # noqa: E999
                case ("/add_user", "POST"):
                    user_id = await app.add_or_login_user(body, user_id)
                    if user_id is not None:
                        new_token = make_token(user_id)
                    else:
                        need_update = True
                case ("/add_task", "POST"):
                    app.add_task(user_id, body)
                case ("/edit_task", "POST"):
                    app.edit_task(user_id, body)
                case ("/delete_task", "POST"):
                    app.delete_task(user_id, body)
                case ("/get_list_tasks", "GET"):
                    res = app.delete_task(user_id, body)
                case _:
                    raise EndpointError(f"body: {body}")
        except (app.BadField, EndpointError):
            await send({
                'type': 'http.response.start',
                'status': 400,
                'headers': [
                    [b'content-type', b'text/plain'],
                ],
            })

            await send({
                    'type': 'http.response.body',
                    'response': "bad request",
            })

        await send_response(send, res, new_token, need_update)
    else:
        await send({
            'type': 'http.response.start',
            'status': 200,
            'headers': [
                [b'Content-type', b'application/json'],
                [b'Accept', b'application/json'],
                [b"access-control-allow-origin", b'*'],
                [b"Access-Control-Allow-Methods", b"*"]
            ]
        })
        await send({
            'type': 'http.response.body',
            'body': "{\"field\" : \"success\"}".encode('utf-8'),
        })

