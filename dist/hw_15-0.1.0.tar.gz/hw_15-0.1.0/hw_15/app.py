from typing import Any, Optional

from hw_15.models import User, Task
from hw_15.db import db
import html


class BadField(Exception):
    pass


def get_field(body: dict, name: str) -> Any:
    val = body.get(name, None)
    if val is not None and (type(val) is str and html.escape(val) != val):
        raise BadField
    return val


async def add_or_login_user(body: dict,
                            op_user_id: Optional[Any]) -> Optional[Any]:
    login = get_field(body, "login")
    password = get_field(body, "password")
    is_admin = get_field(body, "is_admin")

    user_id = db.find_user_by_login_and_passwrod(login, password)
    if user_id is not None and op_user_id == user_id:
        return user_id
    elif user_id is not None and op_user_id != user_id:
        return None
    else:
        user_id = db.add_user_or_admin(User(login, password, is_admin))
        return user_id


async def add_task(user_id: Optional[Any], body: dict) -> None:
    if user_id is None:
        raise BadField

    task_name = get_field(body, "task_name")
    db.add_task(Task(task_name, user_id))


async def edit_task(user_id: Optional[Any], body: dict) -> None:
    if user_id is None:
        return None

    task_name = get_field(body, "task_name")
    task_id = get_field(body, "task_id")

    task_ids = list(map(lambda task: task.user_id,
                        db.find_tasks_by_user_id(user_id)))
    if task_id in task_ids:
        db.edit_task(task_id, task_name)


async def delete_task(user_id:  Optional[Any], body: dict) -> None:
    if user_id is None:
        raise BadField

    task_id = get_field(body, "task_id")

    task_ids = list(map(lambda task: task.user_id,
                        db.find_tasks_by_user_id(user_id)))
    if task_id in task_ids:
        db.delete_task(task_id)


async def get_tasks_list(user_id:  Optional[Any]) -> list[dict[str, str]]:
    if user_id is None:
        raise BadField

    tasks = db.find_tasks_by_user_id(user_id)
    res = []
    for task in tasks:
        res.append({"task_name": task.task_name, "user_id": task.user_id})
    return res
